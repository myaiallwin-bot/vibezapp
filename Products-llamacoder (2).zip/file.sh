# Install dependencies
npm install

# Start development server
npm start